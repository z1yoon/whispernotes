#!/bin/bash

CERT_FILE="/Projects/ssls/_.leeseng.net.crt"
KEY_FILE="/Projects/ssls/_.leeseng.net.key"

NAMESPACES="gitlab harbor minio whispernotes jupyter"

for ns in $NAMESPACES; do
  echo "---"
  echo "Attempting to create secret in namespace: "
  microk8s kubectl create secret tls "${ns}-tls-secret" \
    	    --cert="$CERT_FILE" \
     	    --key="$KEY_FILE" \
     	    --namespace="${ns}"
done
echo "---"
echo "Script finished."
